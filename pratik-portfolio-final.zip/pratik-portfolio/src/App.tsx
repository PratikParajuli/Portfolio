import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Home as HomeIcon,
  User,
  Cpu,
  FolderGit2,
  Briefcase,
  Mail,
  Menu,
  X,
  MapPin,
  Server,
  Code2,
  Globe,
  Instagram,
  MessageCircle,
  Send,
  Gauge,
  Infinity as InfinityIcon,
  Activity,
  ArrowUpRight,
  Terminal,
  Zap,
} from 'lucide-react';

const NAV = [
  { id: 'home', label: 'HOME', icon: HomeIcon },
  { id: 'about', label: 'ABOUT', icon: User },
  { id: 'skills', label: 'SKILLS', icon: Cpu },
  { id: 'projects', label: 'PROJECTS', icon: FolderGit2 },
  { id: 'experience', label: 'EXPERIENCE', icon: Briefcase },
  { id: 'contact', label: 'CONTACT', icon: Mail },
];

const SKILLS = [
  {
    icon: Server,
    title: 'Minecraft Server Development',
    pct: 96.96,
    desc: 'Paper, Purpur, Spigot, optimization, and security tuning.',
    tags: ['Paper', 'Purpur', 'Spigot', 'Optimization', 'Security'],
  },
  {
    icon: Code2,
    title: 'Custom Java Plugins',
    pct: 92.5,
    desc: 'Java 21, Spigot API, databases, and custom mechanics.',
    tags: ['Java 21', 'Spigot API', 'Databases', 'Custom Mechanics'],
  },
  {
    icon: Globe,
    title: 'Web Development',
    pct: 45.0,
    desc: 'HTML, CSS, JavaScript, Tailwind.',
    tags: ['HTML', 'CSS', 'JavaScript', 'Tailwind'],
  },
];

const METRICS = [
  { icon: Gauge, label: 'TPS TARGET', value: '20.0', accent: 'cyan' },
  { icon: InfinityIcon, label: 'UPTIME GOAL', value: '∞', accent: 'emerald' },
  { icon: Activity, label: 'LAG SPIKES', value: '0', accent: 'cyan' },
];

const PROJECTS = [
  {
    title: 'Developer Portfolio',
    desc: 'Built from scratch using HTML5, CSS3, JavaScript, and Tailwind CSS. A sleek, dark-tech personal portfolio with an admin dashboard aesthetic.',
    tags: ['HTML5', 'CSS3', 'JavaScript', 'Tailwind CSS'],
    icon: FolderGit2,
  },
];

const EXPERIENCE = [
  {
    role: 'Minecraft Server Engineer',
    org: 'Independent / Freelance',
    period: 'Ongoing',
    desc: 'Architecting high-performance Paper/Purpur servers targeting 20.0 TPS, hardening security, and tuning JVM internals for lag-free gameplay.',
    icon: Server,
  },
  {
    role: 'Java Plugin Developer',
    org: 'Custom Projects',
    period: 'Ongoing',
    desc: 'Designing custom Java 21 plugins on the Spigot API — mechanics, databases, and integrations built for performance and reliability.',
    icon: Code2,
  },
];

const CONTACTS = [
  {
    label: 'Instagram',
    handle: '@nodoubtpratik',
    href: 'https://www.instagram.com/nodoubtpratik',
    icon: Instagram,
    accent: 'cyan',
  },
  {
    label: 'Discord',
    handle: 'Pratik Parajuli',
    href: 'https://discord.com/users/1382730588506689677',
    icon: MessageCircle,
    accent: 'emerald',
  },
  {
    label: 'Email',
    handle: 'mail@pratikparajuli.xyz',
    href: 'mailto:mail@pratikparajuli.xyz',
    icon: Send,
    accent: 'cyan',
  },
];

function useTypewriter(
  segments: { text: string; className?: string }[],
  speed = 55,
  start = true
) {
  const full = useMemo(() => segments.map((s) => s.text).join(''), [segments]);
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    setCount(0);
    let i = 0;
    let timer: ReturnType<typeof setTimeout>;
    const tick = () => {
      i += 1;
      setCount(i);
      if (i < full.length) {
        timer = setTimeout(tick, speed);
      }
    };
    timer = setTimeout(tick, speed + 400);
    return () => clearTimeout(timer);
  }, [full, speed, start]);

  const rendered: React.ReactNode[] = [];
  let consumed = 0;
  for (const seg of segments) {
    if (consumed >= count) break;
    const remaining = count - consumed;
    const slice = seg.text.slice(0, remaining);
    if (slice.length > 0) {
      rendered.push(
        <span key={consumed} className={seg.className}>
          {slice}
        </span>
      );
    }
    consumed += seg.text.length;
  }
  const done = count >= full.length;
  return { rendered, done };
}

function useReveal<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setShown(true);
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return { ref, shown };
}

function useInView<T extends HTMLElement>(threshold = 0.3) {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setInView(true);
            io.unobserve(e.target);
          }
        });
      },
      { threshold }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return { ref, inView };
}

function Section({
  id,
  index,
  label,
  title,
  children,
}: {
  id: string;
  index: string;
  label: string;
  title: string;
  children: React.ReactNode;
}) {
  const { ref, shown } = useReveal<HTMLDivElement>();
  return (
    <section
      id={id}
      ref={ref}
      className="relative mx-auto w-full max-w-6xl px-5 py-20 sm:px-8 sm:py-28"
    >
      <div
        className={`transition-all duration-700 ${
          shown ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
        }`}
      >
        <div className="flex items-center gap-3 font-mono text-xs tracking-[0.3em] text-neon-cyan/80">
          <Terminal className="h-4 w-4" />
          <span>{index}</span>
          <span className="text-slate-600">—</span>
          <span>{label}</span>
        </div>
        <h2 className="mt-3 font-mono text-3xl font-bold text-slate-50 sm:text-4xl">
          {title}
        </h2>
        <div className="neon-rule mt-6 w-full max-w-xs" />
        <div className="mt-10">{children}</div>
      </div>
    </section>
  );
}

function Navbar() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('home');
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const sections = NAV.map((n) => document.getElementById(n.id));
      const y = window.scrollY + window.innerHeight * 0.35;
      for (let i = sections.length - 1; i >= 0; i--) {
        const s = sections[i];
        if (s && s.offsetTop <= y) {
          setActive(NAV[i].id);
          break;
        }
      }
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'border-b border-neon-cyan/15 bg-ink-950/85 backdrop-blur-xl'
          : 'border-b border-transparent bg-transparent'
      }`}
    >
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3 sm:px-8">
        <button
          onClick={() => go('home')}
          className="group flex items-center gap-3"
          aria-label="Home"
        >
          <span className="relative h-9 w-9 overflow-hidden rounded-lg ring-2 ring-neon-cyan/60 shadow-glowCyan">
            <img
              src="/logo.png"
              alt="PRATIK logo"
              className="h-full w-full object-cover"
            />
          </span>
          <span className="font-mono text-sm font-bold tracking-[0.35em] text-slate-100 group-hover:text-neon-cyan transition-colors">
            PRATIK
          </span>
        </button>

        {/* Desktop */}
        <ul className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => (
            <li key={n.id}>
              <button
                onClick={() => go(n.id)}
                className={`group relative px-3 py-2 font-mono text-xs tracking-[0.2em] transition-colors ${
                  active === n.id
                    ? 'text-neon-cyan'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {n.label}
                <span
                  className={`absolute inset-x-3 -bottom-0.5 h-px origin-left bg-neon-cyan transition-transform duration-300 ${
                    active === n.id ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
                  }`}
                />
              </button>
            </li>
          ))}
        </ul>

        {/* Mobile toggle */}
        <button
          onClick={() => setOpen((v) => !v)}
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-neon-cyan/20 text-neon-cyan lg:hidden"
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden border-t border-neon-cyan/10 bg-ink-950/95 backdrop-blur-xl transition-[max-height] duration-300 lg:hidden ${
          open ? 'max-h-96' : 'max-h-0'
        }`}
      >
        <ul className="mx-auto grid max-w-6xl grid-cols-2 gap-2 px-5 py-4 sm:px-8">
          {NAV.map((n) => {
            const Icon = n.icon;
            return (
              <li key={n.id}>
                <button
                  onClick={() => go(n.id)}
                  className={`flex w-full items-center gap-3 rounded-lg border px-3 py-3 font-mono text-xs tracking-[0.2em] transition-colors ${
                    active === n.id
                      ? 'border-neon-cyan/50 bg-neon-cyan/10 text-neon-cyan'
                      : 'border-slate-700/40 text-slate-300 hover:border-neon-cyan/30 hover:text-neon-cyan'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {n.label}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </header>
  );
}

function Hero() {
  const tagline = useTypewriter([
    { text: 'Developer', className: 'text-neon-cyan' },
    { text: ' / ', className: 'text-slate-600' },
    { text: 'Server Engineer', className: 'text-neon-emerald' },
    { text: ' // from Syangja, Nepal', className: 'text-slate-400' },
  ]);
  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center justify-center overflow-hidden pt-20"
    >
      {/* Backdrop */}
      <div className="pointer-events-none absolute inset-0 bg-grid bg-grid-fade animate-gridmove opacity-60" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[36rem] w-[36rem] -translate-x-1/2 rounded-full bg-neon-cyan/10 blur-[120px]" />
      <div className="pointer-events-none absolute bottom-0 right-0 h-[28rem] w-[28rem] rounded-full bg-neon-emerald/10 blur-[120px]" />

      <div className="relative mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-12 px-5 sm:px-8 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <div className="flex items-center gap-2 font-mono text-xs tracking-[0.3em] text-neon-cyan/80">
            <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-neon-emerald" />
            STATUS: ONLINE
          </div>
          <h1 className="mt-5 font-mono text-5xl font-extrabold leading-tight tracking-tight text-slate-50 sm:text-6xl lg:text-7xl">
            PRATIK <span className="text-gradient">PARAJULI</span>
          </h1>
          <p className="mt-5 max-w-xl font-mono text-sm leading-relaxed text-slate-400 sm:text-base">
            {tagline.rendered}
            <span
              className={`ml-0.5 inline-block w-[2px] -translate-y-0.5 self-center bg-neon-cyan transition-opacity ${
                tagline.done ? 'animate-blink' : 'opacity-100'
              }`}
              style={{ height: '1em' }}
            />
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <button
              onClick={() =>
                document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })
              }
              className="group inline-flex items-center gap-2 rounded-lg border border-neon-cyan/40 bg-neon-cyan/10 px-5 py-3 font-mono text-xs tracking-[0.2em] text-neon-cyan transition-all hover:bg-neon-cyan/20 hover:shadow-glowCyan"
            >
              VIEW PROJECTS
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
            <button
              onClick={() =>
                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })
              }
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700/60 px-5 py-3 font-mono text-xs tracking-[0.2em] text-slate-300 transition-all hover:border-neon-emerald/50 hover:text-neon-emerald"
            >
              CONTACT
              <Mail className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Portrait */}
        <div className="lg:col-span-2">
          <div className="relative mx-auto aspect-square w-64 sm:w-80 lg:w-full lg:max-w-sm">
            <div className="absolute inset-0 animate-pulseGlow rounded-3xl" />
            <div className="scanlines relative h-full w-full overflow-hidden rounded-3xl border border-neon-cyan/40 bg-ink-850">
              <img
                src="/logo.png"
                alt="Pratik Parajuli"
                className="h-full w-full object-cover"
              />
              <div className="pointer-events-none absolute inset-0 rounded-3xl ring-1 ring-inset ring-neon-cyan/30" />
              <div className="absolute bottom-3 left-3 flex items-center gap-2 rounded-md border border-neon-cyan/30 bg-ink-950/80 px-2 py-1 font-mono text-[10px] tracking-[0.2em] text-neon-cyan backdrop-blur">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-neon-emerald" />
                ROOT@PRATIK
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll hint */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 font-mono text-[10px] tracking-[0.3em] text-slate-500">
        SCROLL ↓
      </div>
    </section>
  );
}

const ABOUT_BIO =
  "I'm Pratik Parajuli – a developer obsessed with squeezing every last tick out of the JVM and shipping interfaces that feel as sharp as the systems behind them. My playground spans high-performance Minecraft servers, full-stack web work, and the occasional deep dive into digital logic...";

function About() {
  const { ref, inView } = useInView<HTMLParagraphElement>(0.3);
  const bio = useTypewriter([{ text: ABOUT_BIO }], 18, inView);
  return (
    <Section id="about" index="// 01" label="IDENTITY" title="About Me">
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <p
            ref={ref}
            className="text-base leading-relaxed text-slate-300 sm:text-lg"
          >
            {bio.rendered}
            <span
              className={`ml-0.5 inline-block w-[10px] -translate-y-0.5 bg-neon-cyan transition-opacity ${
                bio.done ? 'animate-blink' : 'opacity-100'
              }`}
              style={{ height: '1.1em' }}
            />
          </p>
          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-neon-emerald/30 bg-neon-emerald/10 px-4 py-2 font-mono text-xs tracking-[0.15em] text-neon-emerald">
            <MapPin className="h-4 w-4" />
            Based in Syangja — Gandaki Province, Nepal
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 lg:grid-cols-1">
            {METRICS.map((m) => {
              const Icon = m.icon;
              const accent =
                m.accent === 'cyan'
                  ? 'text-neon-cyan border-neon-cyan/30'
                  : 'text-neon-emerald border-neon-emerald/30';
              return (
                <div
                  key={m.label}
                  className="surface surface-hover flex items-center gap-4 rounded-xl p-4"
                >
                  <div className={`flex h-11 w-11 items-center justify-center rounded-lg border ${accent}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-mono text-2xl font-bold text-slate-50">
                      {m.value}
                    </div>
                    <div className="font-mono text-[10px] tracking-[0.2em] text-slate-400">
                      {m.label}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Section>
  );
}

function SkillBar({ pct, accent }: { pct: number; accent: 'cyan' | 'emerald' }) {
  const { ref, shown } = useReveal<HTMLDivElement>();
  const grad =
    accent === 'cyan'
      ? 'from-neon-cyanDim to-neon-cyan'
      : 'from-neon-emeraldDim to-neon-emerald';
  return (
    <div ref={ref} className="mt-3 h-2 w-full overflow-hidden rounded-full bg-ink-700">
      <div
        className={`h-full rounded-full bg-gradient-to-r ${grad} transition-[width] duration-1000 ease-out`}
        style={{ width: shown ? `${pct}%` : '0%' }}
      />
    </div>
  );
}

function Skills() {
  return (
    <Section id="skills" index="// 02" label="SKILLS MATRIX" title="Skills Matrix">
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {SKILLS.map((s) => {
          const Icon = s.icon;
          const accent =
            s.pct >= 90 ? 'cyan' : s.pct >= 70 ? 'emerald' : 'cyan';
          const accentText =
            accent === 'cyan' ? 'text-neon-cyan' : 'text-neon-emerald';
          const accentBorder =
            accent === 'cyan' ? 'border-neon-cyan/30' : 'border-neon-emerald/30';
          return (
            <div
              key={s.title}
              className="surface surface-hover group rounded-xl p-6"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-11 w-11 items-center justify-center rounded-lg border ${accentBorder} ${accentText}`}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-mono text-sm font-semibold tracking-wide text-slate-100">
                    {s.title}
                  </h3>
                </div>
                <div className={`font-mono text-lg font-bold ${accentText}`}>
                  {s.pct.toFixed(2)}%
                </div>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-slate-400">
                {s.desc}
              </p>
              <SkillBar pct={s.pct} accent={accent} />
              <div className="mt-4 flex flex-wrap gap-2">
                {s.tags.map((t) => (
                  <span
                    key={t}
                    className="rounded-md border border-slate-700/50 bg-ink-800/60 px-2.5 py-1 font-mono text-[10px] tracking-[0.15em] text-slate-400"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}

function Projects() {
  return (
    <Section id="projects" index="// 03" label="PROJECTS" title="Projects">
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {PROJECTS.map((p) => {
          const Icon = p.icon;
          return (
            <div
              key={p.title}
              className="surface surface-hover group relative overflow-hidden rounded-xl p-6"
            >
              <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-neon-cyan/10 blur-3xl transition-opacity duration-300 group-hover:opacity-100 opacity-60" />
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg border border-neon-cyan/30 text-neon-cyan">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="font-mono text-base font-semibold text-slate-100">
                  {p.title}
                </h3>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-slate-400">
                {p.desc}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {p.tags.map((t) => (
                  <span
                    key={t}
                    className="rounded-md border border-neon-cyan/20 bg-neon-cyan/5 px-2.5 py-1 font-mono text-[10px] tracking-[0.15em] text-neon-cyan/90"
                  >
                    {t}
                  </span>
                ))}
              </div>
              <div className="mt-5 flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-slate-500">
                <Zap className="h-3.5 w-3.5 text-neon-emerald" />
                STATUS: SHIPPED
              </div>
            </div>
          );
        })}

        {/* Placeholder card */}
        <div className="surface surface-hover group relative overflow-hidden rounded-xl border-dashed p-6">
          <div className="pointer-events-none absolute -left-10 -bottom-10 h-40 w-40 rounded-full bg-neon-emerald/10 blur-3xl opacity-60" />
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-lg border border-neon-emerald/30 text-neon-emerald">
              <FolderGit2 className="h-5 w-5" />
            </div>
            <h3 className="font-mono text-base font-semibold text-slate-100">
              More Projects On The Way
            </h3>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-slate-400">
            Exciting new Minecraft plugins and server setups currently under
            development. Stay tuned — the build pipeline is always running.
          </p>
          <div className="mt-5 flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-slate-500">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-neon-emerald" />
            STATUS: IN DEVELOPMENT
          </div>
        </div>
      </div>
    </Section>
  );
}

function Experience() {
  return (
    <Section id="experience" index="// 04" label="EXPERIENCE" title="Experience">
      <ol className="relative ml-3 border-l border-neon-cyan/20">
        {EXPERIENCE.map((e, i) => {
          const Icon = e.icon;
          return (
            <li key={i} className="mb-8 ml-6 last:mb-0">
              <span className="absolute -left-[11px] flex h-5 w-5 items-center justify-center rounded-full border border-neon-cyan/40 bg-ink-900">
                <span className="h-1.5 w-1.5 rounded-full bg-neon-cyan" />
              </span>
              <div className="surface surface-hover rounded-xl p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-neon-cyan/25 text-neon-cyan">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-mono text-sm font-semibold text-slate-100">
                        {e.role}
                      </h3>
                      <p className="font-mono text-[11px] tracking-[0.15em] text-slate-500">
                        {e.org}
                      </p>
                    </div>
                  </div>
                  <span className="rounded-md border border-neon-emerald/25 bg-neon-emerald/10 px-2.5 py-1 font-mono text-[10px] tracking-[0.2em] text-neon-emerald">
                    {e.period}
                  </span>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-slate-400">
                  {e.desc}
                </p>
              </div>
            </li>
          );
        })}
      </ol>
    </Section>
  );
}

function Contact() {
  return (
    <Section id="contact" index="// 05" label="CONTACT" title="Contact">
      <p className="mb-8 max-w-2xl text-sm leading-relaxed text-slate-400">
        Direct lines are open. Whether it's a server that needs saving, a plugin
        to build, or infrastructure to harden — reach out through any channel
        below.
      </p>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {CONTACTS.map((c) => {
          const Icon = c.icon;
          const isCyan = c.accent === 'cyan';
          const accentText = isCyan ? 'text-neon-cyan' : 'text-neon-emerald';
          const accentBorder = isCyan
            ? 'border-neon-cyan/30'
            : 'border-neon-emerald/30';
          const accentHover = isCyan
            ? 'hover:shadow-glowCyan'
            : 'hover:shadow-glowEmerald';
          return (
            <a
              key={c.label}
              href={c.href}
              target="_blank"
              rel="noopener noreferrer"
              className={`surface surface-hover group flex flex-col gap-4 rounded-xl p-6 ${accentHover}`}
            >
              <div className="flex items-center justify-between">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-lg border ${accentBorder} ${accentText}`}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <ArrowUpRight
                  className={`h-5 w-5 text-slate-600 transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 ${accentText}`}
                />
              </div>
              <div>
                <div className="font-mono text-[10px] tracking-[0.25em] text-slate-500">
                  {c.label.toUpperCase()}
                </div>
                <div className="mt-1 font-mono text-sm font-semibold text-slate-100 break-all">
                  {c.handle}
                </div>
              </div>
            </a>
          );
        })}
      </div>
    </Section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-neon-cyan/10 bg-ink-950">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-center gap-4 px-5 py-8 sm:px-8">
        <div className="flex items-center gap-3">
          <span className="relative h-8 w-8 overflow-hidden rounded-lg ring-2 ring-neon-cyan/50">
            <img src="/logo.png" alt="PRATIK" className="h-full w-full object-cover" />
          </span>
          <span className="font-mono text-xs tracking-[0.3em] text-slate-400">
            PRATIK PARAJULI
          </span>
        </div>
        <p className="font-mono text-[11px] tracking-[0.15em] text-slate-600">
          © 2026 All Rights Reserved
        </p>
      </div>
    </footer>
  );
}

function Splash() {
  const [gone, setGone] = useState(false);
  const [hidden, setHidden] = useState(false);
  useEffect(() => {
    const fade = setTimeout(() => setGone(true), 1500);
    const unmount = setTimeout(() => setHidden(true), 2200);
    return () => {
      clearTimeout(fade);
      clearTimeout(unmount);
    };
  }, []);
  if (hidden) return null;
  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-ink-950 transition-opacity duration-700 ${
        gone ? 'opacity-0' : 'opacity-100'
      }`}
      aria-hidden={gone}
    >
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-30" />
      <div className="pointer-events-none absolute h-72 w-72 rounded-full bg-neon-cyan/20 blur-[100px]" />
      <div className="relative flex flex-col items-center gap-4 px-6 text-center">
        <div className="flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-neon-emerald/80">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-neon-emerald" />
          BOOT SEQUENCE
        </div>
        <div className="relative rounded-xl border border-neon-cyan/40 bg-ink-900/80 px-6 py-5 shadow-glowCyan backdrop-blur">
          <div className="flex items-center gap-2 border-b border-neon-cyan/15 pb-2 font-mono text-[10px] tracking-[0.2em] text-slate-500">
            <span className="h-2 w-2 rounded-full bg-rose-500/70" />
            <span className="h-2 w-2 rounded-full bg-amber-400/70" />
            <span className="h-2 w-2 rounded-full bg-neon-emerald/70" />
            <span className="ml-2">root@portfolio:~</span>
          </div>
          <p className="mt-3 font-mono text-sm tracking-wide text-neon-cyan sm:text-base">
            INITIALIZING PORTFOLIO{' '}
            <span className="text-slate-600">//</span>{' '}
            <span className="text-neon-emerald">WELCOME TO PRATIK PARAJULI</span>
            <span className="ml-1 inline-block w-[8px] animate-blink bg-neon-cyan align-middle" style={{ height: '1em' }} />
          </p>
        </div>
        <div className="h-1 w-48 overflow-hidden rounded-full bg-ink-700">
          <div
            className={`h-full rounded-full bg-gradient-to-r from-neon-cyanDim to-neon-emerald transition-[width] duration-[1500ms] ease-out ${
              gone ? 'w-full' : 'w-1/3'
            }`}
          />
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <div className="relative min-h-screen bg-ink-950 text-slate-300">
      <Splash />
      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Experience />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
