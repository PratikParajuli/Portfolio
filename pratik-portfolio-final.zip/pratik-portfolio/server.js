import express from 'express';
import cors from 'cors';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_ORIGIN || '*', // restrict to your domain in production
  methods: ['POST', 'OPTIONS'],
}));
app.use(express.json());

// ─── Nodemailer transporter ───────────────────────────────────────────────────
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.gmail.com',
  port: Number(process.env.EMAIL_PORT) || 587,
  secure: false, // true for port 465, false for 587
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// ─── POST /api/contact ────────────────────────────────────────────────────────
app.post('/api/contact', async (req, res) => {
  const { name, email, message } = req.body;

  // Validation
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    return res.status(400).json({ error: 'Name must be at least 2 characters.' });
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'A valid email address is required.' });
  }
  if (!message || typeof message !== 'string' || message.trim().length < 10) {
    return res.status(400).json({ error: 'Message must be at least 10 characters.' });
  }

  const recipientEmail = process.env.RECIPIENT_EMAIL || 'mail@pratikparajuli.xyz';

  const mailOptions = {
    from: `"Portfolio Contact" <${process.env.EMAIL_USER}>`,
    to: recipientEmail,
    replyTo: email.trim(),
    subject: `New message from ${name.trim()} — Portfolio`,
    text: `
Name:    ${name.trim()}
Email:   ${email.trim()}
Message:
${message.trim()}
    `.trim(),
    html: `
<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#05080d;color:#cbd5e1;border-radius:12px;border:1px solid #22d3ee30">
  <h2 style="color:#22d3ee;margin:0 0 16px">New Portfolio Message</h2>
  <p style="margin:0 0 8px"><strong style="color:#e2e8f0">Name:</strong> ${name.trim()}</p>
  <p style="margin:0 0 8px"><strong style="color:#e2e8f0">Email:</strong> <a href="mailto:${email.trim()}" style="color:#22d3ee">${email.trim()}</a></p>
  <p style="margin:0 0 8px"><strong style="color:#e2e8f0">Message:</strong></p>
  <div style="background:#0f172a;border-left:3px solid #22d3ee;padding:12px 16px;border-radius:6px;white-space:pre-wrap">${message.trim()}</div>
</div>
    `.trim(),
  };

  try {
    await transporter.sendMail(mailOptions);
    return res.status(200).json({ success: true, message: 'Message sent successfully.' });
  } catch (err) {
    console.error('Mail error:', err);
    return res.status(500).json({ error: 'Failed to send message. Please try again later.' });
  }
});

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => {
  console.log(`Contact server running on http://localhost:${PORT}`);
});
