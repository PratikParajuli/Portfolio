/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#05080d',
          900: '#0a0f17',
          850: '#0d131c',
          800: '#111824',
          700: '#1a2330',
          600: '#243041',
          500: '#334155',
        },
        neon: {
          cyan: '#22d3ee',
          cyanDim: '#0891b2',
          emerald: '#10b981',
          emeraldDim: '#059669',
        },
      },
      fontFamily: {
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        glowCyan: '0 0 0 1px rgba(34,211,238,0.4), 0 0 24px -4px rgba(34,211,238,0.45)',
        glowEmerald: '0 0 0 1px rgba(16,185,129,0.4), 0 0 24px -4px rgba(16,185,129,0.45)',
      },
      keyframes: {
        floaty: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        pulseGlow: {
          '0%,100%': { boxShadow: '0 0 0 1px rgba(34,211,238,0.35), 0 0 18px -6px rgba(34,211,238,0.5)' },
          '50%': { boxShadow: '0 0 0 1px rgba(34,211,238,0.6), 0 0 36px -2px rgba(34,211,238,0.7)' },
        },
        scan: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' },
        },
        blink: {
          '0%,100%': { opacity: '1' },
          '50%': { opacity: '0' },
        },
        gridmove: {
          '0%': { backgroundPosition: '0 0' },
          '100%': { backgroundPosition: '40px 40px' },
        },
      },
      animation: {
        floaty: 'floaty 6s ease-in-out infinite',
        pulseGlow: 'pulseGlow 3.5s ease-in-out infinite',
        scan: 'scan 6s linear infinite',
        blink: 'blink 1.1s step-end infinite',
        gridmove: 'gridmove 8s linear infinite',
      },
    },
  },
  plugins: [],
};
