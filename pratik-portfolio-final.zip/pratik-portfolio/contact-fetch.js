/**
 * contact-fetch.js
 * Drop this logic into your contact form's submit handler.
 * Replace API_URL with your deployed backend URL.
 */

const API_URL = 'http://localhost:3001'; // change to your deployed backend URL in production

/**
 * Sends contact form data to the backend.
 * @param {{ name: string, email: string, message: string }} formData
 * @returns {Promise<{ success?: boolean, error?: string }>}
 */
async function sendContactForm({ name, email, message }) {
  const response = await fetch(`${API_URL}/api/contact`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, message }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Something went wrong.');
  }

  return data;
}

// ─── Example: wiring up a real HTML form ─────────────────────────────────────
//
// HTML:
// <form id="contact-form">
//   <input    id="name"    type="text"  placeholder="Your name"    required />
//   <input    id="email"   type="email" placeholder="Your email"   required />
//   <textarea id="message"             placeholder="Your message"  required></textarea>
//   <button type="submit">Send Message</button>
//   <p id="form-status"></p>
// </form>

document.getElementById('contact-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();

  const btn    = e.target.querySelector('button[type="submit"]');
  const status = document.getElementById('form-status');

  const name    = document.getElementById('name').value.trim();
  const email   = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();

  // Basic client-side guard
  if (!name || !email || !message) {
    status.textContent = 'Please fill in all fields.';
    status.style.color = '#f87171';
    return;
  }

  btn.disabled    = true;
  btn.textContent = 'Sending…';
  status.textContent = '';

  try {
    await sendContactForm({ name, email, message });
    status.textContent = "✓ Message sent! I'll get back to you soon.";
    status.style.color = '#10b981';
    e.target.reset();
  } catch (err) {
    status.textContent = err.message;
    status.style.color = '#f87171';
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Send Message';
  }
});
